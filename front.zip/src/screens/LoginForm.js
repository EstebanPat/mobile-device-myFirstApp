import React from 'react'
import { Text, View } from 'react-native'

const LoginForm = () => {
  return (
    <View>
        <Text>Formulario de Log in</Text>
    </View>
  )
}

export default LoginForm
