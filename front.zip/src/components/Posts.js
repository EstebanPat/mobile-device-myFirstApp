import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, FlatList, Image, Modal, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';

export const Posts = () => {
    const [postsList, setPostsList] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [newPost, setNewPost] = useState({
        title: "", subtitle: "", description: "", avatar: "", active: false
    })

    const handleCreatePost = () => {
        axios.post(`http://localhost:3000/api/v1/posts/new-post`,{
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(newPost)
        }
        ).then((response) =>console.log('Data', response.data))
        .catch((error) =>{console.log(error)})
    }
    const handleDeletePost = (postId) => {
        const updatePosts = postsList.filter((post) => post._id !== postId)
        setPostsList(updatePosts)
        axios.delete(`http://localhost:3000/api/v1/posts/${postId}`)
        .then((response) =>console.log('Data', response.data))
        .catch((error) =>{console.log(error)})
            
    }

    const listPosts = () => {
        axios.get(`http://localhost:3000/api/v1/posts/`)
        .then((response) =>{
            console.log('Data', response.data);
            setPostsList(response.data)
        })
        .catch((error) =>{console.log(error)})
    }

    useEffect(() => {
        listPosts()
    })
  return (
    <SafeAreaView style={{marginTop: 30}}>
        <FlatList data={postsList} keyExtractor={(item) =>item._id}
        renderItem={({item}) => (
            <View>
                <Image source={{uri: item.avatar}} style={{width: 50}}/>
                <Text>{item.title}</Text>
                <Text>{item.subtitle}</Text>
                <Text>{item.description}</Text>
                <Text>{item.active? "Y" : "N"}</Text>
                <Button title="Delete" onPress={() =>handleDeletePost(item._id)} />
            </View>
        )}

        />

        <Button title='New Post' onPress={() => setModalVisible(true)} />
        <Modal visible={modalVisible} onRequestClose={() => setModalVisible(false)} animationType='slide'>
            <View style={styles.modalContainer}>
                <TextInput placeholder='Title Post' style={StyleSheet.input} 
                onChangeText={(title_text) =>{
                    console.log(title_text);
                    setNewPost({... newPost, title: title_text})
                }} />

                <TextInput placeholder='SubTitle Post' style={StyleSheet.input} 
                onChangeText={(subtitle_text) =>{
                    console.log(subtitle_text);
                    setNewPost({... newPost, subtitle: subtitle_text})
                }} />

                <TextInput placeholder='Avatar' style={StyleSheet.input} 
                onChangeText={(avatar_text) =>{
                    console.log(avatar_text);
                    setNewPost({... newPost, subtitle: avatar_text})
                }} />

                <TextInput placeholder='Description Post' style={StyleSheet.input} 
                onChangeText={(description_text) =>{
                    console.log(description_text);
                    setNewPost({... newPost, subtitle: description_text})
                }} />

                <Button onPress={handleCreatePost} title='Crear'></Button>

            </View>
        </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
    modalContainer:{
        flex: 1,
        justifyContent: "center",
        alignContent: "center",
        alignItems: "center"
    },
    input:{
        marginBottom: 10,

    }
})